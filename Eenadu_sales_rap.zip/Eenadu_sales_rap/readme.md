# Learn Owl in 50 Minutes

This repository contains the code for my talk `Learn Owl in 50 Minutes`.

## How to run the code

- clone this repo somewhere
- start odoo with this repo in the addons-path, on a recent version (odoo > 16.4)
- install the `oxp` addon
- go to the `/oxp` route to see the result.

The commit history should correspond to the content for each steps in the talk.
