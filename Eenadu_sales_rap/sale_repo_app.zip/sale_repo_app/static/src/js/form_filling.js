/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

const NEWSPAPERS = [
    "Deccan Chronicle", "Eenadu", "AndhraJyoti", "The Hindu", "Namasthe Telangana",
    "Metro India", "The Hans India", "Nava Telangana", "The Deccan Times", "Hindi Milap", "Prajasakti"
];
const PROFESSIONS = [
    "Farmer", "Doctor", "Teacher", "Lawyer", "Artist", "Musician", "Chef", "Photographer",
    "Electrician", "Plumber", "Designer", "Writer", "Social Worker", "Marketing Specialist", "Accountant"
];

export class SelfCustomerFormFillingSalesRep extends Component {
    static template = "sale_repo_app.customer_form_filling_file";

    setup() {
        this.PROFESSIONS = PROFESSIONS;
        this.rpc = useService("rpc");
        const today = new Date();
        const date = today.toISOString().split('T')[0];
        const time = today.toTimeString().slice(0, 5);
        this.state = useState({
            date,
            time,
            family_head_name: "",
            father_name: "",
            mother_name: "",
            spouse_name: "",
            house_number: "",
            street_number: "",
            city: "",
            pin_code: "",
            address: "",
            mobile_number: "",
            eenadu_newspaper: true, // true=Yes, false=No
            feedback_to_improve_eenadu_paper: "",
            read_newspaper: false,
            current_newspaper: "",
            reason_for_not_taking_eenadu_newsPaper: "",
            reason_not_reading: "",
            free_offer_15_days: false,
            reason_not_taking_offer: "",
            employed: true,
            job_type: "", // "govt" or "private"
            job_type_one: "", // Central/PSU/State
            job_profession: "",
            job_designation: "",
            company_name: "",
            profession: "",
            job_designation_one: "",
            select_profession: "",
            latitude: "",
            longitude: "",
            showModal: false,
            modalType: "",
        });
    }

    toggle(key) {
        this.state[key] = !this.state[key];
    }

    showDropdown(type) {
        this.state.showModal = true;
        this.state.modalType = type;
    }

    selectDropdownItem(type, value) {
        this.state[type] = value;
        this.closeDropdownModal();
    }

    closeDropdownModal() {
        this.state.showModal = false;
        this.state.modalType = "";
    }

    async getLocation() {
        if (!navigator.geolocation) {
            alert("❌ Geolocation not supported.");
            return;
        }
        navigator.geolocation.getCurrentPosition(
            pos => {
                this.state.latitude = pos.coords.latitude;
                this.state.longitude = pos.coords.longitude;
                alert(`📍 Latitude: ${this.state.latitude} Longitude: ${this.state.longitude}`);
            },
            err => {
                alert("❌ Error getting location: " + err.message);
            }
        );
    }

    // Used to check if a form section/field should be shown or required
    get showFeedbackToImprove() { return !this.state.eenadu_newspaper; }
    get showReadNewspaperSection() { return !this.state.eenadu_newspaper; }
    get showCurrentPaperSection() { return this.state.read_newspaper; }
    get showNoNewsReason() { return !this.state.read_newspaper; }
    get showFreeTrialSection() { return !this.state.eenadu_newspaper; }
    get showPrivateJobFields() { return !this.state.employed ? false : (this.state.job_type === "private"); }
    get showGovtJobFields() { return !this.state.employed ? false : (this.state.job_type === "govt"); }
    get showProfessionField() { return !this.state.employed; }
    get showJobType() { return this.state.employed; }
    get showJobDesignationOne() { return this.state.job_type === "private" && this.state.employed; }
    get showJobTypeOne() { return this.state.job_type === "govt" && this.state.employed; }

    async submitForm(ev) {
        ev.preventDefault();
        const formData = { ...this.state };
        // optional: sanitize/transform fields before sending
        try {
            const res = await this.rpc("/for/api/customer_form", { ...formData });
            if (res.result || res.status === "success") {
                alert("✅ Data Submitted Successfully!");
                // Optionally reset the form here...
            } else {
                alert("❌ Submission Failed: " + (res.error?.message || ""));
            }
        } catch (err) {
            alert("❌ Error submitting form: " + err.message);
        }
    }
}

registry.category("actions").add("sale_repo_app.self_customer_form_filling_sales_rep", SelfCustomerFormFillingSalesRep);
